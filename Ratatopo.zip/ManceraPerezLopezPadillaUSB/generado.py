#Copyright 2022 Tomas Mancera Villa - Sebastian Lopez - Juan Manuel Padilla - Carlos Perez
def flujo_control(): 
  """flujo_control"""
  #Declara e inicializa
  int = 0
  #Lee
  #Calcula
  #Imprime resultados
  return 0

def main():
  """funcion main."""
  flujo_control()
  print("Plantilla de código en Python generada de manera exitosa!")
  return 0
main()
