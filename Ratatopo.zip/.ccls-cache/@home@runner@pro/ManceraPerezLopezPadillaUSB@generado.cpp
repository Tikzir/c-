// Copyright 2022 Tomas Mancera Villa - Sebastian Lopez - Juan Manuel Padilla - Carlos Perez
#include <iostream>
#include <string>

/*
flujoControl
*/

int flujoControl (){
//Declarar e inicializar
char letra = 'a';
int entero = 0;
std::string cadena = " ";
//Lee
//Calcula
//Imprime resultados
return (0);
}

/*
Funcion main
*/
int main(){
flujoControl();
std::cout<<"Plantilla de código en C/C++ generada de manera exitosa!";
return 0;
}